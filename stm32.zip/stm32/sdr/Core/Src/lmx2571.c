/*
 * lmx2571.c
 *
 *  Created on: Sep 1, 2026
 *      Author: Josh
 */

#include "lmx2571.h"

uint32_t regs[45] = {
	0x3CA000,
	0x3A8C00,
	0x357806,
	0x2F0000,
	0x2E001E,
	0x2A0210,
	0x290810,
	0x28101C,
	0x2711FB,
	0x233E87,
	0x220000,
	0x210000,
	0x200000,
	0x1F0000,
	0x1E0000,
	0x1D0000,
	0x1C0000,
	0x1B0000,
	0x1A0000,
	0x190000,
	0x18000E,
	0x170E84,
	0x168584,
	0x150101,
	0x14301B,
	0x1303E8,
	0x120000,
	0x110000,
	0x100000,
	0x0F0000,
	0x0E0000,
	0x0D0000,
	0x0C0000,
	0x0B0000,
	0x0A0000,
	0x090000,
	0x08000E,
	0x070E80,
	0x060584,
	0x050101,
	0x04201A,
	0x031200,
	0x020000,
	0x017A00,
	0x000483
};

HAL_StatusTypeDef lmx2571_write_vb(uint8_t addr, uint16_t data) {
	HAL_StatusTypeDef status;

	uint8_t packet[3];
	// RW bit 0 for write
	packet[0] = addr & 0x7f;
	packet[1] = (data >> 8) & 0xff;
	packet[2] = data & 0xff;

	HAL_GPIO_WritePin(PLL_NSS_GPIO_Port, PLL_NSS_Pin, GPIO_PIN_RESET);

	status = HAL_SPI_Transmit(&hspi3, packet, 3, 100);

	HAL_GPIO_WritePin(PLL_NSS_GPIO_Port, PLL_NSS_Pin, GPIO_PIN_SET);

	return status;
}

HAL_StatusTypeDef lmx2571_write(uint32_t data) {
	HAL_StatusTypeDef status;

	uint8_t packet[3];

	packet[0] = (data >> 16) & 0xff;
	packet[1] = (data >> 8) & 0xff;
	packet[2] = data & 0xff;

	HAL_GPIO_WritePin(PLL_NSS_GPIO_Port, PLL_NSS_Pin, GPIO_PIN_RESET);
	status = HAL_SPI_Transmit(&hspi3, packet, 3, 100);

	HAL_GPIO_WritePin(PLL_NSS_GPIO_Port, PLL_NSS_Pin, GPIO_PIN_SET);

	return status;
}

HAL_StatusTypeDef lmx2571_read_vb(uint8_t addr, uint16_t *data) {
	HAL_StatusTypeDef status;
	// RW bit 0 for write
	uint8_t packet = (addr & 0x7f) | (1 << 7);
	uint8_t rx_buffer[2];

	HAL_GPIO_WritePin(PLL_NSS_GPIO_Port, PLL_NSS_Pin, GPIO_PIN_RESET);
	HAL_SPI_Transmit(&hspi3, &packet, 1, 100);

	status = HAL_SPI_Receive(&hspi3, rx_buffer, 2, 100);

	HAL_GPIO_WritePin(PLL_NSS_GPIO_Port, PLL_NSS_Pin, GPIO_PIN_SET);

	*data = (rx_buffer[0] << 8) | rx_buffer[1];

	return status;
}

int lmx2571_load_config() {
	int failure = 1;

	for (int i = 0; i < 45; i++) {
		if (lmx2571_write(regs[i]) == HAL_ERROR) {
			failure = -1;
			break;
		}
	}

	return failure;
}

void lmx2571_reset() {
	lmx2571_write_vb(0x00, 1 << 13);
}
