/*
 * ltc5599.c
 *
 *  Created on: Sep 1, 2026
 *      Author: Josh
 */


#include "ltc5599.h"

static void write_byte(uint8_t byte) {
	// Setup/hold way too long
	for (int i = 7; i >= 0; i--) {
		HAL_GPIO_WritePin(MOD_SDI_GPIO_Port, MOD_SDI_Pin, byte & (1 << i) ? GPIO_PIN_SET : GPIO_PIN_RESET);
		HAL_Delay(1);
		HAL_GPIO_WritePin(MOD_CLK_GPIO_Port, MOD_CLK_Pin, GPIO_PIN_SET);
		HAL_Delay(1);
		HAL_GPIO_WritePin(MOD_CLK_GPIO_Port, MOD_CLK_Pin, GPIO_PIN_RESET);
		HAL_Delay(1);
	}
}

static void hold_bus() {
	HAL_GPIO_WritePin(MOD_CLK_GPIO_Port, MOD_CLK_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(MOD_SDI_GPIO_Port, MOD_SDI_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(MOD_NSS_GPIO_Port, MOD_NSS_Pin, GPIO_PIN_RESET);
}

static void release_bus() {
	HAL_GPIO_WritePin(MOD_NSS_GPIO_Port, MOD_NSS_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(MOD_CLK_GPIO_Port, MOD_CLK_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(MOD_SDI_GPIO_Port, MOD_SDI_Pin, GPIO_PIN_RESET);
}

void ltc5599_enable() {
	release_bus();
	HAL_GPIO_WritePin(MOD_EN_GPIO_Port, MOD_EN_Pin, GPIO_PIN_SET);
}

void ltc5599_disable() {
	HAL_GPIO_WritePin(MOD_EN_GPIO_Port, MOD_EN_Pin, GPIO_PIN_RESET);
}

int ltc5599_write(uint8_t adr, uint8_t data) {
	hold_bus();
	// 0 LSB indicates write
	adr <<= 1;

	write_byte(adr);
	write_byte(data);
	release_bus();
}

uint8_t ltc5599_read(uint8_t adr) {
	hold_bus();
	write_byte(1 | (adr << 1));

	uint8_t data = 0;
	GPIO_PinState state;

	for (int i = 7; i >= 0; i--) {
		HAL_GPIO_WritePin(MOD_CLK_GPIO_Port, MOD_CLK_Pin, GPIO_PIN_SET);
		HAL_Delay(1);

		state = HAL_GPIO_ReadPin(MOD_SDO_GPIO_Port, MOD_SDO_Pin);
		data |= ((state == GPIO_PIN_SET) ? 1 : 0) << i;

		HAL_GPIO_WritePin(MOD_CLK_GPIO_Port, MOD_CLK_Pin, GPIO_PIN_RESET);
		HAL_Delay(1);
	}

	release_bus();

	return data;
}

void ltc5599_reset() {
	ltc5599_write(0x08, 1 << 3);
}
