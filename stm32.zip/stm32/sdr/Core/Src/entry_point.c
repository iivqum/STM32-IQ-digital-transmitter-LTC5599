/*
 * entry_point.c
 *
 *  Created on: Sep 1, 2026
 *      Author: Josh
 */

#include "entry_point.h"
#include "main.h"

cc_state_t control_state;
receiver_buffer_t receiver;
dacbuf_t dac_buffer;
uint8_t dac_intermediate[DAC_BUFFER_SIZE * 2];
uint8_t stream_stalled = 0;

static void rearm_endpoint() {
	USBD_CDC_ReceivePacket(&hUsbDeviceFS);
}

int8_t usb_receiver_packet_handler(uint8_t *buf, uint32_t *len) {
	//uint8_t *write_loc = receiver_get_write_location(&receiver);
	receiver_write(&receiver, buf, *len);
	USBD_CDC_SetRxBuffer(&hUsbDeviceFS, receiver_get_write_location(&receiver));

	if (receiver_available(&receiver) == RX_MAX_PACKETS) {
		stream_stalled = 1;

		return USBD_BUSY;
	}

	USBD_CDC_ReceivePacket(&hUsbDeviceFS);

	return USBD_OK;
}

int usb_read(volatile uint8_t *buf) {
	if (receiver.locked == 1)
		return -1;

	// What happens when you read everything after the receiver was just full?
	// Seems unlikely but could happen
	// We end up skipping to rearm the endpoint

	if (receiver_available(&receiver) == 0) {
		return -1;
	}

	receiver_read(&receiver, buf);

	if (stream_stalled) {
		stream_stalled = 0;

		rearm_endpoint();
	}

	return 1;
}

void usb_write(uint8_t *buf, uint32_t len) {
	uint8_t status;
	uint8_t tries = 0;
	do {
		status = CDC_Transmit_FS(buf, len);
		tries++;
	} while ((status == USBD_BUSY) && (tries <= 10));
}

void dac_stream() {
	//while (!(dac_buffer.wr_lower || dac_buffer.wr_upper)) {}
	uint32_t block = 0;

	while (block <= 7) {
		if (usb_read(dac_intermediate + block * 64) == -1)
			continue;

		if (receiver.previous_packet->len == 0) {
			control_state.type = NONE;
			break;
		}

		block++;
	}

	dac_buffer.data_ready = 1;
	receiver_lock(&receiver);
}

void fullcbk(DMA_HandleTypeDef *dma) {
	//dac_buffer.wr_upper = 1;
	//dac_buffer.wr_lower = 0;
	if (dac_buffer.data_ready == 0)
		return;

	//dac_buffer.write = dac_buffer.data + DAC_BUFFER_SIZE;
	HAL_DMA_Start_IT(&hdma_memtomem_dma1_channel2, (uint32_t)dac_intermediate, (uint32_t)(dac_buffer.data + DAC_BUFFER_SIZE), DAC_BUFFER_SIZE * 2);
	//receiver_unlock(&receiver);
}

void halfcbk(DMA_HandleTypeDef *dma) {
	if (dac_buffer.data_ready == 0)
		return;
	//dac_buffer.wr_lower = 1;
	//dac_buffer.wr_upper = 0;
	//dac_buffer.write = dac_buffer.data;
	//receiver_unlock(&receiver);
	HAL_DMA_Start_IT(&hdma_memtomem_dma1_channel2, (uint32_t)dac_intermediate, (uint32_t)dac_buffer.data, DAC_BUFFER_SIZE * 2);
}

void errorcbk(DMA_HandleTypeDef *dma) {

}

void mem2mem_complete_callback(DMA_HandleTypeDef *dma) {
	dac_buffer.data_ready = 0;

	receiver_unlock(&receiver);
}

void mem2mem_error_callback(DMA_HandleTypeDef *dma) {
	dac_buffer.data_ready = 0;

	receiver_unlock(&receiver);
}

void entry_point() {
	lmx2571_reset();
	//lmx2571_load_config();

	ltc5599_enable();
	ltc5599_reset();
	// Optimize LO filter for 500 MHz
	//ltc5599_write(0x00, 0x2e);

	//HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_1, DAC_ALIGN_8B_R, 255);
	//HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_2, DAC_ALIGN_8B_R, 127);

	for (int i = 0; i < DAC_BUFFER_SIZE * 2; i++) {
		dac_buffer.data[i] = 0;
	}

	HAL_DMA_RegisterCallback(&hdma_memtomem_dma1_channel2, HAL_DMA_XFER_CPLT_CB_ID, mem2mem_complete_callback);
	HAL_DMA_RegisterCallback(&hdma_memtomem_dma1_channel2, HAL_DMA_XFER_ERROR_CB_ID, mem2mem_error_callback);

	// Zero indicates the upper/lower half can't be written to
	dac_buffer.wr_lower = 0;
	dac_buffer.wr_upper = 0;
	dac_buffer.data_ready = 0;
	dac_buffer.write = dac_buffer.data;

	//HAL_StatusTypeDef status;
	//HAL_DAC_Start_DMA(&hdac1, DAC_CHANNEL_1, (uint32_t *)dac_buffer.data, DAC_BUFFER_SIZE * 2, DAC_ALIGN_8B_R);
	//HAL_DAC_Start_DMA(&hdac1, DAC_CHANNEL_2, (uint32_t *)samples2, 500, DAC_ALIGN_8B_R);
	SET_BIT(hdac1.Instance->CR, DAC_CR_DMAEN1);
	__HAL_DAC_ENABLE_IT(&hdac1, DAC_IT_DMAUDR1);

	HAL_DMA_RegisterCallback(hdac1.DMA_Handle1, HAL_DMA_XFER_CPLT_CB_ID, fullcbk);
	HAL_DMA_RegisterCallback(hdac1.DMA_Handle1, HAL_DMA_XFER_HALFCPLT_CB_ID, halfcbk);
	HAL_DMA_RegisterCallback(hdac1.DMA_Handle1, HAL_DMA_XFER_ERROR_CB_ID, errorcbk);
	HAL_DMA_Start_IT(hdac1.DMA_Handle1, (uint32_t)dac_buffer.data, (uint32_t)&hdac1.Instance->DHR8RD, DAC_BUFFER_SIZE * 2);
	//HAL_DMA_Start();

	HAL_DAC_Start(&hdac1, DAC_CHANNEL_1);
	HAL_DAC_Start(&hdac1, DAC_CHANNEL_2);

	HAL_TIM_Base_Start(&htim6);

	control_state.bytes_remaining = 0;
	control_state.type = NONE;

	uint8_t packet[64];

	uint32_t block = 0;

	while (1) {
		HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_SET);


		if (control_state.type == DAC_STREAM) {
			dac_stream();

			continue;
		}

		if (usb_read(packet) == -1)
			continue;

		if (*(uint32_t *)packet != 0xdeadbeef)
			continue;

		/*
		Every  command except DAC_STREAM are single packet commands, i.e they are less than 64 bytes
		long
		*/

		switch (packet[4]) {
			case PLL_READ:
				//receiver_read(&receiver, control_state.buf, 1);
				lmx2571_read_vb(packet[5], (uint16_t *)&control_state.buf[1]);
				usb_write(&control_state.buf[1], 2);
				break;

			case PLL_WRITE:
				//receiver_read(&receiver, control_state.buf, 3);
				lmx2571_write_vb(packet[5], *(uint16_t *)&packet[6]);
				break;

			case MOD_READ:
				//receiver_read(&receiver, control_state.buf, 1);

				control_state.buf[1] = ltc5599_read(packet[5]);

				usb_write(&control_state.buf[1], 1);
				break;

			case MOD_WRITE:
				//receiver_read(&receiver, control_state.buf, 2);
				ltc5599_write(packet[5], packet[6]);
				break;

			case DAC_REQUEST:
				control_state.buf[0] = dac_buffer.wr_lower || dac_buffer.wr_upper;
				usb_write(control_state.buf, 1);
				break;

			case DAC_STREAM:
				//dac_stream();

				control_state.type = DAC_STREAM;

				break;

			default:
				break;
		}

		HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);
	}
}
