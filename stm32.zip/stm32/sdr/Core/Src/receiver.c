/*
 * buffer.c
 *
 *  Created on: Sep 11, 2026
 *      Author: Josh
 */

#include "receiver.h"

uint32_t receiver_available(receiver_buffer_t *rec) {
	uint32_t wr = rec->wr;
	uint32_t rd = rec->rd;

	if (wr >= rd)
		return wr - rd;

	return ((RX_MAX_PACKETS + 1) - rd) + wr;
}

uint32_t receiver_remaining(receiver_buffer_t *rec) {
	return (rec->len - 1) - rec->wr;
}

volatile uint8_t *receiver_get_write_location(receiver_buffer_t *rec) {
	return rec->packets[rec->wr].data;
}

int receiver_write(receiver_buffer_t *rec, uint8_t *buf, uint32_t len) {
	uint32_t wr = rec->wr;
	uint32_t rd = rec->rd;
	uint32_t new_idx = (wr + 1) % (RX_MAX_PACKETS + 1);
	// Don't overtake reader
	if ((new_idx == rd))
		return -1;

	rec->packets[wr].len = len;
	rec->wr = new_idx;

	return 1;
}

uint32_t receiver_read(receiver_buffer_t *rec, volatile uint8_t *buf) {
	uint32_t wr = rec->wr;
	uint32_t rd = rec->rd;

	if ((rd == wr))
		return 0;

	uint32_t length = rec->packets[rd].len;

	memcpy(buf, rec->packets[rd].data, length);

	rec->previous_packet = &rec->packets[rd];
	rec->rd = (rd + 1) % (RX_MAX_PACKETS + 1);

	return length;
}

uint32_t receiver_read16b(receiver_buffer_t *rec, volatile uint16_t *buf) {
	if (rec->rd == rec->wr)
		return 0;

	uint32_t length = rec->packets[rec->rd].len;

	for (int i = 0; i < length; i++) {
		buf[i] = (uint16_t)(rec->packets[rec->rd].data[i]);
	}

	rec->rd = (rec->rd + 1) % (RX_MAX_PACKETS + 1);

	return length;
}

uint32_t receiver_flush(receiver_buffer_t *rec) {
	rec->wr = 0;
	rec->rd = 0;

	return 0;
}

void receiver_lock(receiver_buffer_t *rec) {
	rec->locked = 1;
}

void receiver_unlock(receiver_buffer_t *rec) {
	rec->locked = 0;
}

uint32_t receiver_init(receiver_buffer_t *rec, uint8_t *buf, uint32_t len) {
	rec->data = buf;
	rec->len = len;
	rec->wr = 0;
	rec->rd = 0;
	rec->lb = 0;
	rec->locked = 0;
	rec->tick = 0;

	for (int i = 0; i < (RX_MAX_PACKETS + 1); i++) {
		rec->packets[i].data = rec->packet_buffer + i * RX_PACKET_SIZE;
	}

	return 0;
}
