/*
 * lmx2571.h
 *
 *  Created on: Sep 1, 2026
 *      Author: Josh
 */

#ifndef INC_LMX2571_H_
#define INC_LMX2571_H_

#include "main.h"

extern SPI_HandleTypeDef hspi3;

HAL_StatusTypeDef lmx2571_write_vb(uint8_t addr, uint16_t data);
HAL_StatusTypeDef lmx2571_write(uint32_t data);
HAL_StatusTypeDef lmx2571_read_vb(uint8_t addr, uint16_t *data);

int lmx2571_load_config();
void lmx2571_reset();

#endif /* INC_LMX2571_H_ */
