/*
 * entry_point.h
 *
 *  Created on: Sep 1, 2026
 *      Author: Josh
 */

#ifndef INC_ENTRY_POINT_H_
#define INC_ENTRY_POINT_H_

#include "stm32g4xx_hal.h"
#include "lmx2571.h"
#include "ltc5599.h"
#include "receiver.h"
#include "usbd_cdc.h"
#include "usbd_cdc_if.h"

#define DAC_BUFFER_SIZE 256

extern receiver_buffer_t receiver;

// Command & control
typedef enum cc_type {
	NONE = 0x01,
	DAC_STREAM,
	PLL_READ,
	PLL_WRITE,
	MOD_READ,
	MOD_WRITE,
	// To request if we can send data to the DAC
	DAC_REQUEST
} cc_type_t;

typedef struct cc_state {
	cc_type_t type;
	uint32_t bytes_remaining;
	uint8_t buf[8];
} cc_state_t;

typedef struct dacbuf {
	volatile uint16_t data[DAC_BUFFER_SIZE * 2];
	volatile uint8_t *write;
	// Flags to indicate which part of the buffer can be written to
	volatile uint8_t wr_upper, wr_lower;
	volatile uint8_t data_ready;
} dacbuf_t;

extern DAC_HandleTypeDef hdac1;
extern DMA_HandleTypeDef hdma_memtomem_dma1_channel2;
extern TIM_HandleTypeDef htim6;
extern DMA_HandleTypeDef hdma_dac1_ch1;
extern USBD_HandleTypeDef hUsbDeviceFS;

void entry_point();

int8_t usb_receiver_packet_handler(uint8_t *buf, uint32_t *len);

#endif /* INC_ENTRY_POINT_H_ */
