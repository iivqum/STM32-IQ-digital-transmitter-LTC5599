/*
 * buffer.h
 *
 *  Created on: Sep 11, 2026
 *      Author: Josh
 */

#ifndef INC_RECEIVER_H_
#define INC_RECEIVER_H_

#include "stm32g4xx_hal.h"
#include "usbd_def.h"
#include <string.h>

#define RX_MAX_PACKETS (uint32_t)32
#define RX_PACKET_SIZE (uint32_t)64

typedef struct receiver_packet {
	volatile uint8_t *data;
	volatile uint32_t len;
} receiver_packet_t;

typedef struct receiver_buffer {
	volatile uint8_t *data;
	volatile uint32_t wr, rd, len, lb;
	volatile uint8_t locked;
	volatile uint32_t tick;
	volatile uint8_t packet_buffer[(RX_MAX_PACKETS + 1) * RX_PACKET_SIZE];
	receiver_packet_t packets[RX_MAX_PACKETS + 1];
	receiver_packet_t *previous_packet;
} receiver_buffer_t;

uint32_t receiver_available(receiver_buffer_t *rec);
uint32_t receiver_remaining(receiver_buffer_t *rec);
int receiver_write(receiver_buffer_t *rec, uint8_t *buf, uint32_t len);
volatile uint8_t *receiver_get_write_location(receiver_buffer_t *rec);
uint32_t receiver_read(receiver_buffer_t *rec, volatile uint8_t *buf);
uint32_t receiver_read16b(receiver_buffer_t *rec, volatile uint16_t *buf);
uint32_t receiver_flush(receiver_buffer_t *rec);
uint32_t receiver_init(receiver_buffer_t *rec, uint8_t *buf, uint32_t len);
void receiver_lock(receiver_buffer_t *rec);
void receiver_unlock(receiver_buffer_t *rec);

#endif /* INC_RECEIVER_H_ */
