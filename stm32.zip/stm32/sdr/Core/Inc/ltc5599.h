/*
 * ltc5599.h
 *
 *  Created on: Sep 1, 2026
 *      Author: Josh
 */

#ifndef INC_LTC5599_H_
#define INC_LTC5599_H_

#include "main.h"

int ltc5599_write(uint8_t adr, uint8_t data);
void ltc5599_reset();
uint8_t ltc5599_read(uint8_t adr);
void ltc5599_enable();
void ltc5599_disable();

#endif /* INC_LTC5599_H_ */
